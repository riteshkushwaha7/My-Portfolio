# Spotify-clone
Created by Ritesh Kushwaha 
github.com/riteshkushwaha497
******************************************************************************
Front-End Minor Project
Spotify Clone
Completed on 9 dec 2023 at 3:00a.m

******************************************************************************
languages used HTML, CSS only
******************************************************************************
You can see this project live on 
https://spotify-clone-phi-neon.vercel.app/
